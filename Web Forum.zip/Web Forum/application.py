#!/usr/bin/env python3
# -*- coding: utf-8 -*-
'''
Projeto Aplicação Web

Formulários e Banco de Dados

Para instalar a biblioteca flask_sqlalchemy: pip install flask_sqlalchemy

Professor: Álvaro Campos Ferreira
Contato: alvaro.ferreira@idp.edu.br
'''

from flask import Flask, url_for, render_template, request, redirect, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import login_user, logout_user, current_user, UserMixin, LoginManager
import sqlalchemy
from datetime import datetime


app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///test.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)
login_manager = LoginManager(app)
# Essa função deve ser inserida para que o login_manager consiga achar o usuário pelo id. Ver documentação.
@login_manager.user_loader
def load_user(id):
    return User.query.get(int(id))


class User(db.Model,UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True)
    password = db.Column(db.String(80))

    def __init__(self, username, password):
        self.username = username
        self.password = password

class Thread(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.Integer, db.ForeignKey('user.username'))
    title = db.Column(db.String(80), unique=True)
    body = db.Column(db.String(80))
    date = db.Column(db.DateTime, nullable=False)


    def __init__(self, username, title, body, date):
        self.username = username
        self.title = title 
        self.body = body
        self.date = date

class Comment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.Integer, db.ForeignKey('user.username'))
    thread_id = db.Column(db.Integer, db.ForeignKey('thread.id'))
    body = db.Column(db.String(80))
    date = db.Column(db.DateTime, nullable=False)


    def __init__(self, thread_id, body, date, username):
        self.thread_id = thread_id
        self.username = username
        self.body = body
        self.date = date



@app.route("/", methods=['GET', 'POST'])
def index():
    # if session['logged_in']:
        # name = current_user.username
        # return render_template('index.html',name=name)
    # else:
        return render_template('index.html')
    
@app.route("/sobre")
def sobre():
    return render_template('sobre.html')

@app.route("/recursos")
def recursos():
    return render_template('recursos.html')

@app.route("/forum", methods=['GET', 'POST'])
def forum():
    if session['logged_in']:
        name = current_user.username
        recentes = Thread.query.order_by(sqlalchemy.desc(Thread.date)).limit(10)
        if request.method == 'POST':
            nova_thread = Thread(
                username = current_user.username,
                title = request.form['title'] ,
                body = request.form['body'],
                date = datetime.now())
            db.session.add(nova_thread)
            db.session.commit()
            # return render_template('forum.html',name=name,recentes=recentes)
            return redirect(url_for('thread', id=nova_thread.id,title=nova_thread.title,thread=nova_thread,body=nova_thread.body))
        else:
            return render_template('forum.html',name=name,recentes=recentes)
    else:
        return 'Acesso negado'
    

@app.route("/thread", methods=['GET', 'POST'])
def thread():
    id= request.args.get("id")
    thread = Thread.query.filter_by(id=id).first()
    if session['logged_in']:
        id= request.args.get("id")
        print(id)
        thread = Thread.query.filter_by(id=id).first()
        print(thread)
        name = current_user.username
        # recentes = Comment.query.filter_by(thread_id=thread.id).order_by(sqlalchemy.desc(Comment.date)).limit(10)
        if request.method == 'POST':
            novo_coment = Comment(
                username = current_user.username,
                thread_id = thread.id,
                body = request.form['body'],
                date = datetime.now())
            db.session.add(novo_coment)
            db.session.commit()
        recentes = Comment.query.filter_by(thread_id=thread.id).order_by(sqlalchemy.desc(Comment.date)).limit(10)
        return render_template('thread.html',id=id,name=name,thread=thread,thread_user=thread.username,recentes=recentes)
    else:
        return 'Acesso negado'
    


@app.route('/registrar', methods=['GET', 'POST'])
def registrar():
    if request.method == 'POST':
        new_user = User(
            username=request.form['username'],
            password=request.form['password'])
        db.session.add(new_user)
        db.session.commit()
        return render_template('login.html')
    return render_template('registrar.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('login.html')
    else:
        name = request.form['username']
        passw = request.form['password']
        # try:
        data = User.query.filter_by(username=name, password=passw).first()
        if data is not None:
            session['logged_in'] = True
            login_user(data)
            return redirect(url_for('index',name=name))
        else:
            return 'Erro login - usuário não encontrado'
        # except:
            # return "Erro Login"

@app.route("/logout")
def logout():
    session['logged_in'] = False
    logout_user()
    return redirect(url_for('index'))

@app.route("/delete", methods=['GET', 'POST'])
def delete():
    if request.method == 'POST':
        name = request.form['username']
        user = User.query.filter_by(username=name).first()
        db.session.delete(user)
        db.session.commit()
    return render_template('delete.html')



if __name__ == '__main__':
    app.debug = True
    db.create_all()
    app.secret_key = "123"
    app.run(host='0.0.0.0')
